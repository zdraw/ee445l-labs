#include <hidef.h>      /* common defines and macros */
#include "derivative.h"      /* derivative-specific definitions */

//---------------------switch_Init---------------------
// Set PP6-4 as inputs
// Input: none
// Output: none  
void switch_Init(void);