void DAC_Init(void);
void Music_InitOC7(void);
void Music_EnableOC7(void);